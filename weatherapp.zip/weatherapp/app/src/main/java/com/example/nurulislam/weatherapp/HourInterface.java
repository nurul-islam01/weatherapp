package com.example.nurulislam.weatherapp;

import com.example.nurulislam.weatherapp.Hourly.HourlyForecast;

public interface HourInterface {
    public void hourObjectPass(HourlyForecast hourlyForcast);
}
