package com.example.nurulislam.weatherapp;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;


import com.example.nurulislam.weatherapp.Weekly.WeeklyForecast;

import java.util.List;

public class ForcastFragment extends Fragment implements WeeklyObjectPass{


    public ForcastFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_forcast, container, false);
        return v;
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        context = getActivity();
        ((MainActivity) context).setWeeklyObject(this);
    }


    @Override
    public void setWeeklyObjectpass(WeeklyForecast weeklyForecast) {

    }
}
