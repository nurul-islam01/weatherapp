package com.example.nurulislam.weatherapp;

import com.example.nurulislam.weatherapp.Current.CurrentWeather;

public interface CurrentWeatherInterface {
    public void pasObjectWeather(CurrentWeather currentWeather);
}
