package com.example.nurulislam.weatherapp;

import com.example.nurulislam.weatherapp.Weekly.WeeklyForecast;
import com.example.nurulislam.weatherapp.Weekly.WeeklyForecast;

import retrofit2.http.GET;

public interface WeeklyObjectPass {
    @GET
    void setWeeklyObjectpass(WeeklyForecast weeklyForecast);
}
