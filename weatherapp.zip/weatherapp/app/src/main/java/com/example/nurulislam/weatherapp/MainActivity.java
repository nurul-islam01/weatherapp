package com.example.nurulislam.weatherapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.example.nurulislam.weatherapp.Current.CurrentWeather;
import com.example.nurulislam.weatherapp.Hourly.HourlyForecast;
import com.example.nurulislam.weatherapp.Weekly.WeeklyForecast;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import java.io.IOException;
import java.util.List;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static java.util.jar.Pack200.Packer.ERROR;

public class MainActivity extends AppCompatActivity {
    private TabLayout tabLayout;
    private ViewPager viewPager;


    public static final String CURRENT_BASE_URL = "http://api.openweathermap.org/data/2.5/";
    public static final String YAHOO_BASE_URL = "https://query.yahooapis.com/v1/public/";

    private CurrnetApi currnetApi;
    private HourApi hourApi;
    private WeekApi weekApi;
    private String units = "metric";
    private String city;

    private double lat, lon;
    private CurrentWeatherInterface currentWeatherInterface;
    private HourInterface hourInterface;
    private WeeklyObjectPass weeklyObjectPass;


    private FusedLocationProviderClient client;
    private LocationRequest request;
    private LocationCallback callback;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tabLayout = findViewById(R.id.tabLayoutId);
        viewPager = findViewById(R.id.viewPagerId);

        //Locaton

        client = LocationServices.getFusedLocationProviderClient(this);
        request = new LocationRequest();
        callback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                for(Location location : locationResult.getLocations()){
                    lat = location.getLatitude();
                    lon = location.getLongitude();
//                    hourlyForecast();
                    appLocation();
                }
            }
        };
        request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        request.setInterval(10000);
        request.setFastestInterval(5000);
        getDeviceUpdateLocations();
        getDeviceCurrentLocation();


        tabLayout.addTab(tabLayout.newTab().setText("Current"));
        tabLayout.addTab(tabLayout.newTab().setText("7 DAYS FORCAST"));

        WeatherPagerAdapter adapter = new WeatherPagerAdapter(getSupportFragmentManager(),tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        appLocation();
//        hourlyForecast();
    }
    public void pasObjectCurrentWeather(CurrentWeatherInterface currentWeatherInterface){
        this.currentWeatherInterface = currentWeatherInterface;
    }

    public void setWeeklyObject(WeeklyObjectPass weeklyObjectPass){
        this.weeklyObjectPass = weeklyObjectPass;
    }
    public void setHourInterface(HourInterface hourInterface){
        this.hourInterface = hourInterface;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == 11 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
            getDeviceUpdateLocations();
            getDeviceCurrentLocation();
        }
    }



    private class WeatherPagerAdapter extends FragmentPagerAdapter{
        private int tabCount;
        public WeatherPagerAdapter(FragmentManager fm,int tabCount  ) {
            super(fm);
            this.tabCount = tabCount;
        }

        @Override
        public Fragment getItem(int position) {
            switch (position){
                case 0:
                    return new CurrentFragment();
                case 1:
                    return new ForcastFragment();
            }
            return null;
        }

        @Override
        public int getCount() {
            return tabCount;
        }
    }


    public void appLocation(){

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(CURRENT_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        hourApi = retrofit.create(HourApi.class);
        String apiKey = getString(R.string.weather_api_key);

        String customUrl1 = String.format("forecast?lat=%f&lon=%f&units=%s&appid=%s",lat,lon,units,apiKey);

        Call<HourlyForecast> called =  hourApi.getHourlyApi(customUrl1);
        called.enqueue(new Callback<HourlyForecast>() {
            @Override
            public void onResponse(Call<HourlyForecast> call, Response<HourlyForecast> response) {
                if (response.isSuccessful()){
                    HourlyForecast hourlyForecast = response.body();
                    String cit = hourlyForecast.getCity().getName();
                    city = cit;
                    hourInterface.hourObjectPass(hourlyForecast);
                }
            }

            @Override
            public void onFailure(Call<HourlyForecast> call, Throwable t) {
                Log.e("tipu", "onFailure: "+t.toString());
                Toast.makeText(MainActivity.this, ""+t.toString(), Toast.LENGTH_LONG).show();
            }
        });


        currnetApi = retrofit.create(CurrnetApi.class);
        String customUrl = String.format("weather?lat=%f&lon=%f&units=%s&appid=%s",lat,lon,units,apiKey);

        final Call<CurrentWeather> currentWeatherCall = currnetApi.getCurrentApi(customUrl);

        currentWeatherCall.enqueue(new Callback<CurrentWeather>() {
            @Override
            public void onResponse(Call<CurrentWeather> call, Response<CurrentWeather> response) {
                if(response.code() == 200){
                    final CurrentWeather currentWeather = response.body();
                    currentWeatherInterface.pasObjectWeather(currentWeather);
                    }
            }

            @Override
            public void onFailure(Call<CurrentWeather> call, Throwable t) {
            }
        });
        if (city !=null){
//            Toast.makeText(this, ""+city, Toast.LENGTH_SHORT).show();
            Retrofit retrofit1 = new Retrofit.Builder()
                    .baseUrl(YAHOO_BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
            weekApi = retrofit1.create(WeekApi.class);
            String url = "yql?q=select * from weather.forecast where woeid in (select woeid from geo.places(1) where text%3D\"c%2C"+city+"\")&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
            final Call<WeeklyForecast> weeklyForecastCall = weekApi.setWeekApi(url);
            weeklyForecastCall.enqueue(new Callback<WeeklyForecast>() {
                @Override
                public void onResponse(Call<WeeklyForecast> call, Response<WeeklyForecast> response) {
                    if (response.isSuccessful()){
                        WeeklyForecast weeklyForecast = response.body();
                        weeklyObjectPass.setWeeklyObjectpass(weeklyForecast);
                    }
                    else {
                        Toast.makeText(MainActivity.this, ""+response.errorBody().toString(), Toast.LENGTH_SHORT).show();
                    }

                }

                @Override
                public void onFailure(Call<WeeklyForecast> call, Throwable t) {
                    Toast.makeText(MainActivity.this, ""+t.toString(), Toast.LENGTH_LONG).show();
                }
            });

        }



//

    }


    //location methods

    private void getDeviceUpdateLocations() {
        if(checkLocationPermission()){
            client.requestLocationUpdates(request,callback,null);
        }else{
            checkLocationPermission();
        }
    }


    public boolean checkLocationPermission(){
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION},11);
            return false;
        }
        return true;
    }
    public void getDeviceCurrentLocation(){
        if(checkLocationPermission()){
            client.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if(location == null){
                        return;
                    }
                    lat = location.getLatitude();
                    lon = location.getLongitude();
                    //getWeatherData();
                }

            });
        }else{
            checkLocationPermission();
        }
    }

}
