package com.example.nurulislam.weatherapp;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.nurulislam.weatherapp.Current.CurrentWeather;
import com.example.nurulislam.weatherapp.Hourly.HourlyForecast;
import com.example.nurulislam.weatherapp.Hourly.List;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;


public class CurrentFragment extends Fragment implements CurrentWeatherInterface,HourInterface {

    private static final String HOUR_ICON_BASE_URL = "http://openweathermap.org/img/w/";

    private TextView cityTV,dateTime,tempText,cloude,cloudePercent,sunriseTV,sunsetTV;
    private GridView gridView;
    private ImageView iconImage;

    private TextView hourDeg1,hourDeg2,hourDeg3,hourDeg4,hourTime1,hourTime2,hourTime3,hourTime4;
    private ImageView hourIcon1,hourIcon2,hourIcon3,hourIcon4;

    public CurrentFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        final View v = inflater.inflate(R.layout.fragment_current, container, false);
        cityTV = v.findViewById(R.id.cityTextView);
        dateTime = v.findViewById(R.id.dateTime);
        tempText = v.findViewById(R.id.tempText);
        cloude = v.findViewById(R.id.cloude);
        cloudePercent = v.findViewById(R.id.cloudePercent);
        iconImage = v.findViewById(R.id.iconImage);
        sunriseTV = v.findViewById(R.id.sunrise);
        sunsetTV = v.findViewById(R.id.sunset);

        //hourly ids find
        hourDeg1 = v.findViewById(R.id.hourDeg1);
        hourDeg2 = v.findViewById(R.id.hourDeg2);
        hourDeg3 = v.findViewById(R.id.hourDeg3);
        hourDeg4 = v.findViewById(R.id.hourDeg4);
        hourTime1 = v.findViewById(R.id.hourTime1);
        hourTime2 = v.findViewById(R.id.hourTime2);
        hourTime3 = v.findViewById(R.id.hourTime3);
        hourTime4 = v.findViewById(R.id.hourTime4);

        //hour Icons
        hourIcon1 = v.findViewById(R.id.hourIcon1);
        hourIcon2 = v.findViewById(R.id.hourIcon2);
        hourIcon3 = v.findViewById(R.id.hourIcon3);
        hourIcon4 = v.findViewById(R.id.hourIcon4);

        return v;

    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        context = getActivity();
        ((MainActivity)context).pasObjectCurrentWeather(this);
        ((MainActivity)context).setHourInterface(this);

    }



    @Override
    public void pasObjectWeather(CurrentWeather currentWeather) {

        cityTV.setText(currentWeather.getName().toUpperCase().toString());
        int tim = currentWeather.getDt();
        long l = (long)tim;
        String date = new java.text.SimpleDateFormat("EEEE, d MMM, hh:mm aaa").format(new java.util.Date (l*1000));


        dateTime.setText(date.toString());
        double temp =currentWeather.getMain().getTemp();
        int tmp = (int) temp;
        String tmpString = String.valueOf(tmp).toString()+"°c";
        tempText.setText(tmpString);
        String cloudperc = currentWeather.getClouds().getAll().toString()+"%";
        cloudePercent.setText(cloudperc);
        cloude.setText(currentWeather.getWeather().get(0).getMain().toUpperCase());

        switch (currentWeather.getWeather().get(0).getIcon().toString()){
            case "01d":
                iconImage.setImageResource(R.drawable.o1d);
                break;
            case "02d":
                iconImage.setImageResource(R.drawable.o2d);
                break;
            case "03d":
                iconImage.setImageResource(R.drawable.o3d);
                break;
            case "04d":
                iconImage.setImageResource(R.drawable.o4d);
                break;
            case "09d":
                iconImage.setImageResource(R.drawable.o9d);
                break;
            case "10d":
                iconImage.setImageResource(R.drawable.o10d);
                break;
            case "13d":
                iconImage.setImageResource(R.drawable.o13d);
                break;
            case "50d":
                iconImage.setImageResource(R.drawable.o50d);
                break;
            case "01n":
                iconImage.setImageResource(R.drawable.o1n);
                break;
            case "02n":
                iconImage.setImageResource(R.drawable.o2n);
                break;
            case "03n":
                iconImage.setImageResource(R.drawable.o3n);
                break;
            case "04n":
                iconImage.setImageResource(R.drawable.o4n);
                break;
            case "09n":
                iconImage.setImageResource(R.drawable.o9n);
                break;
            case "10n":
                iconImage.setImageResource(R.drawable.o10n);
                break;
            case "11n":
                iconImage.setImageResource(R.drawable.o11n);
                break;
             case "13n":
                iconImage.setImageResource(R.drawable.o13n);
                break;
             case "50n":
                iconImage.setImageResource(R.drawable.o50n);
                break;
        }

        int sunr = currentWeather.getSys().getSunrise();
        String sunrise = new java.text.SimpleDateFormat("HH:mm aa ").format(new java.util.Date (sunr*1000));
        sunriseTV.setText(sunrise);

        int suns = currentWeather.getSys().getSunrise();
        String sunset = new java.text.SimpleDateFormat(" hh:mm aa").format(new java.util.Date (suns*1000));
        sunsetTV.setText(sunset);
    }

    @Override
    public void hourObjectPass(HourlyForecast hourlyForcast) {




        double t1 = hourlyForcast.getList().get(0).getMain().getTemp();
        double t2 = hourlyForcast.getList().get(1).getMain().getTemp();
        double t3 = hourlyForcast.getList().get(2).getMain().getTemp();
        double t4 = hourlyForcast.getList().get(3).getMain().getTemp();
        int temp1 = (int) t1;
        int temp2 = (int) t2;
        int temp3 = (int) t3;
        int temp4 = (int) t4;
        hourDeg1.setText(String.valueOf(temp1)+"°c");
        hourDeg2.setText(String.valueOf(temp2)+"°c");

        hourDeg3.setText(String.valueOf(temp3)+"°c");
        hourDeg4.setText(String.valueOf(temp4)+"°c");

        String icon1 = HOUR_ICON_BASE_URL+hourlyForcast.getList().get(0).getWeather().get(0).getIcon()+".png";
        Picasso.get().load(icon1).into(hourIcon1);

        String icon2 = HOUR_ICON_BASE_URL+hourlyForcast.getList().get(1).getWeather().get(0).getIcon()+".png";
        Picasso.get().load(icon2).into(hourIcon2);

        String icon3 = HOUR_ICON_BASE_URL+hourlyForcast.getList().get(2).getWeather().get(0).getIcon()+".png";
        Picasso.get().load(icon3).into(hourIcon3);

        String icon4 = HOUR_ICON_BASE_URL+hourlyForcast.getList().get(4).getWeather().get(0).getIcon()+".png";
        Picasso.get().load(icon4).into(hourIcon4);

        int ti1 = hourlyForcast.getList().get(0).getDt();
        String time1 = new java.text.SimpleDateFormat("hh aaa").format(new java.util.Date (ti1*1000));
        hourTime1.setText(time1.toString());

        int ti2 = hourlyForcast.getList().get(1).getDt();
        String time2 = new java.text.SimpleDateFormat("hh aaa").format(new java.util.Date (ti2*1000));
        hourTime2.setText(time2.toString());

        int ti3 = hourlyForcast.getList().get(2).getDt();
        String time3 = new java.text.SimpleDateFormat("hh aaa").format(new java.util.Date (ti3*1000));
        hourTime3.setText(time3.toString());

         int ti4 = hourlyForcast.getList().get(3).getDt();
        String time4 = new java.text.SimpleDateFormat("hh aaa").format(new java.util.Date (ti3*1000));
        hourTime4.setText(time4.toString());


    }


}
