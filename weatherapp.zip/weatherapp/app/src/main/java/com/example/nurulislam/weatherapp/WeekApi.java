package com.example.nurulislam.weatherapp;

import com.example.nurulislam.weatherapp.Weekly.WeeklyForecast;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public interface WeekApi {
    @GET
    Call<WeeklyForecast> setWeekApi(@Url String urlString);
}
